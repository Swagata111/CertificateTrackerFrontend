export class PlannedTrainings
{
    empId: string;
	empName: string;
    trainingId: string;
	trainingName:string;
	trainingStatus: string;
	nominationStatus: string;
	requestDate: string;
	startDate:string;
	endDate:string;
	location:string;
	

}