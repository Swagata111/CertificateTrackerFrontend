import { Component, OnInit,ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { BreakpointObserver } from '@angular/cdk/layout';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { CertificatePojo } from '../certificatepojo';
import { RegisterService } from '../register.service';
import { voucher } from '../voucher';
import { PlannedCertification } from '../plannedcertification';
import { MatSort, MatPaginator } from '@angular/material';

@Component({
  selector: 'app-all-vouchers',
  templateUrl: './all-vouchers.component.html',
  styleUrls: ['./all-vouchers.component.css']
})
export class AllVouchersComponent implements OnInit {

  model: voucher[];
  displayedColumns: string[] = ['voucherCode','stream','examName', 'status', 'expiryDate','empId','empName'];
  dataSource = new MatTableDataSource();
  searchKey:string;
  emp:CertificatePojo;
  empName:string;
  cerName:string[];
  currentPc:PlannedCertification;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  pageSizeOptions: number[] = [5, 10, 25, 50,100,150,200,500,1000,2000,3000,5000,10000];

  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {
      
    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

     
  ngOnInit() {
    this.res.gettingAllVouchers().subscribe(res=>
    {
      this.dataSource.data=res;
      this.dataSource.sort = this.sort;

        });
        this.dataSource.paginator = this.paginator;

  }
  
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }

  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }

}
