export class Trainings
{
    trainingId:string;
    trainingName:string;
    stream:string;
    startDate:string;
    endDate:string;
    startTime:string;
    endTime:string;
    trainerName:string;
    city:string;
    location:string;
    status:string;
    capacity:number;
    interestsReceived:number;
    confirmedOrApproved:number;
    seatsRemaining:number;
}