import { Component, OnInit ,ViewChild} from '@angular/core';
import { MatTableDataSource, MatIconRegistry, MatDialogConfig, MatDialog, MatSort, MatPaginator } from '@angular/material';
import { RegisterService } from '../register.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { AdminAddCorecertComponent } from '../admin-add-corecert/admin-add-corecert.component';
import { EditCertificationListComponent } from '../edit-certification-list/edit-certification-list.component';

@Component({
  selector: 'app-admin-configaration',
  templateUrl: './admin-configaration.component.html',
  styleUrls: ['./admin-configaration.component.css']
})
export class AdminConfigarationComponent implements OnInit {

  displayedColumns: string[] = ['certificationCategory', 'certificationName','activeStatus', 'coreCeritification','level', 'voucherAvailable','delete','edit'];
  dataSource = new MatTableDataSource();
  public popoverTitle: string = 'Certification Tracker';
  public popoverMessage: string = 'Are you sure you want to delete this certification ?';
  length = 1000;
  pageSize = 5;
  // itemsPerPageLabel="Certifications per Page"
  pageSizeOptions: number[] = [5, 10, 25, 50,100,150,200,500];

  public confirmClicked: boolean = false;
  public cancelClicked: boolean = false;

  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;


  searchKey:string;
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        iconRegistry.addSvgIcon(
          'delete',
          sanitizer.bypassSecurityTrustResourceUrl('assets/delete.svg'));
          
            iconRegistry.addSvgIcon(
              'Edit',
            sanitizer.bypassSecurityTrustResourceUrl('assets/Edit.svg'));
            
  
      }
    
  ngOnInit(){
    this.dataSource.paginator = this.paginator;

    this.res.getCoreCer().subscribe(res=>
      {
        this.dataSource.data=res;
        this.dataSource.sort = this.sort;

      });
  }
  oncreate(){
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.open(AdminAddCorecertComponent,dialogconfig); 
  }
  onEdit(element)
  {
    this.res.storeCore(element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.open(EditCertificationListComponent,dialogconfig);
  }
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }
  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }

  deleteCoreCertification(_id)
  {

    this.res.deleteCorecertification(_id)  
      .subscribe(  
        data => {  
          console.log(data);    
        },  
        error => console.log(error));  
      window.location.reload();

  
}
}

