export class CertificatePojo
{ 
	empId: string;
	_id:string;
	empName: string;
	cerCategory:string;
	cerName: string;
	cerDate: string;
	expDate: string;
	cerMonth: string;
	examScore: string;
	voucherCode: string;
	localGrade:string;
	location:string;
	globalPractice:string;
	 file:File;
	 fileName:string;
}