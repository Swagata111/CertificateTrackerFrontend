import { Component, OnInit, ViewChild } from '@angular/core';
import { CertificatePojo } from '../certificatepojo';
import { MatTableDataSource, MatSort, MatIconRegistry, MatPaginator } from '@angular/material';
import { RegisterService } from '../register.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { ExcelService } from '../excel.service';
import * as fileSaver from 'file-saver'; // npm i --save file-saver

@Component({
  selector: 'app-admin-all-certifications-show',
  templateUrl: './admin-all-certifications-show.component.html',
  styleUrls: ['./admin-all-certifications-show.component.css']
})
export class AdminAllCertificationsShowComponent implements OnInit {

  displayedColumns: string[] = ['empId','empName','cerCategory','cerName', 'cerDate', 'expDate','cerMonth','certificate','download','view','location','localGrade','globalPractice'];
  model: CertificatePojo[];
  length = 1000;
  public Null:null;
  pageSize = 5;
  regForm: FormGroup;
  cerDateFilter = new FormControl('');
  cerCatFilter = new FormControl('');
  cerMonthFilter=new FormControl('');
  locationFilter = new FormControl('');
  globalPracticeFilter = new FormControl('');

;


  filterValues = {
    cerCategory: '',
    cerMonth:'',
    location:'',
    globalPractice:'',

  }
  showMsg:Boolean=false;
  public userFile:any= File;
  // itemsPerPageLabel="Certifications per Page"
  pageSizeOptions: number[] = [5, 10, 25, 50,100,150,200,500,1000,2000,3000,5000,10000];

  dataSource = new MatTableDataSource();
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  searchKey:string;
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, private excelService:ExcelService,
    sanitizer: DomSanitizer,
    private fb:FormBuilder,
    private route:Router) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        
        iconRegistry.addSvgIcon(
          'download',
          sanitizer.bypassSecurityTrustResourceUrl('assets/download.svg'));
  
          iconRegistry.addSvgIcon(
            'eye',
            sanitizer.bypassSecurityTrustResourceUrl('assets/eye.svg'));
  
      }
    
  ngOnInit(){

    this.dataSource.paginator = this.paginator;
    this.dataSource.filterPredicate = this.createFilter();
    
    this.res.getAllCertificatesAdmin().subscribe(res=>
      {
        this.dataSource.data=res;
        this.dataSource.sort=this.sort;


      });

      this.cerCatFilter.valueChanges.subscribe(

        cerCategory => {
          this.filterValues.cerCategory = cerCategory;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
     
      this.cerMonthFilter.valueChanges.subscribe(

        cerMonth => {
          this.filterValues.cerMonth= cerMonth;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.locationFilter.valueChanges
      .subscribe(
        location => {
          this.filterValues.location = location;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
  
      this.globalPracticeFilter.valueChanges
      .subscribe(
        globalPractice => {
          this.filterValues.globalPractice = globalPractice;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
  
  }

  download(_id,fileName,empName)
  {
    console.log(_id);
    this.res.downloadPdf(_id) 
    .subscribe(response => {
       const filename:string = empName+"_"+fileName;
      console.log(filename);
      this.saveFile(response.body, filename);
    });
    
}

saveFile(data: any, filename?: string) {
  const blob = new Blob([data], {type: 'application/pdf'});
  // const blob = new Blob([data]);

  fileSaver.saveAs(blob, filename);
}

viewPdf(_id,fileName)
{
  this.res.viewPdf(_id)
  .subscribe(response => {
    var fileURL = URL.createObjectURL(response);
    window.open(fileURL,'_blank');
    
 });


}

  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }

  clearCerMonth()
  {
    this.cerMonthFilter.setValue('');
    
  }

  clearCerCat(){
    this.cerCatFilter.setValue('');
  }
  clearLocation()
  {
    this.locationFilter.setValue('');
  }
  clearGP()
  {
    this.globalPracticeFilter.setValue('');
  }

  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
  selectedFiles: FileList;
   currentFileUpload: File;
  onSelectFile(event)
  {
    this.selectedFiles = event.target.files;
  }

 
createFilter(): (data: any, filter: string) => boolean {
  let filterFunction = function(data, filter): boolean {
    let searchTerms = JSON.parse(filter);
    return data.cerCategory.toLowerCase().indexOf(searchTerms.cerCategory) !== -1
    && data.cerMonth.toLowerCase().indexOf(searchTerms.cerMonth) !== -1
    && data.globalPractice.toLowerCase().indexOf(searchTerms.globalPractice) !== -1
    && data.location.toLowerCase().indexOf(searchTerms.location) !== -1


    // || data.cerDate.toLowerCase().indexOf(searchTerms.cerDate) !== -1;

  }
  return filterFunction;
  }

  exportAsXLSX():void {
    this.excelService.exportAsExcelFile(this.dataSource.filteredData, 'EmployeeCertificationFiltered');
 }

}
