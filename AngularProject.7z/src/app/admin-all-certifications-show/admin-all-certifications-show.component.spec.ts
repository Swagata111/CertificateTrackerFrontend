import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAllCertificationsShowComponent } from './admin-all-certifications-show.component';

describe('AdminAllCertificationsShowComponent', () => {
  let component: AdminAllCertificationsShowComponent;
  let fixture: ComponentFixture<AdminAllCertificationsShowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminAllCertificationsShowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAllCertificationsShowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
