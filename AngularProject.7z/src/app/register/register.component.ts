import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RegisterPojo } from '../registerpojo';
import { Router } from '@angular/router';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  regForm: FormGroup;

  submitted= false;
  register:RegisterPojo=new RegisterPojo();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router) { }

  ngOnInit() {
    this.regForm = this.fb.group({
      name: ['', [Validators.required,Validators.maxLength(20),Validators.minLength(3) ]],
  
      emailId: ['',[ Validators.required,Validators.pattern('[a-zA-Z0-9_.+-]+@capgemini.com+$')] ],
      
      empId: ['',[Validators.required]],

      password:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6),	Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')] ],

      confirmpassword:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6),	Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')] ],

      

    });
  }
  reg(){
    this.submitted = true;
    this.register=new RegisterPojo();

  }
  check=false;
  onRegister(){
    this.submitted=true;
    this.check=true;
    this.log.create(this.register)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)
            
            this.route.navigateByUrl('register');
      });


  }

}

