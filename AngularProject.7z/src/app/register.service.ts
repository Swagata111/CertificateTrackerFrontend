import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { HttpClient, HttpEvent, HttpRequest, HttpHeaders, HttpResponse } from '@angular/common/http';
import { CertificatePojo } from './certificatepojo';
import { CoreCertificatePojo } from './corecertificatepojo';
import { Tower } from './tower';
import { AdminVoucherPojo } from './adminvoucherpojo';
import { PlannedCertification } from './plannedcertification';
import { EmployeePojo } from './employeepojo';
import {  AssignVoucher } from './AssignVoucher';
import { voucher } from './voucher';
import { Trainings } from './Trainings';
import { PlannedTrainings } from './plannedTrainings';

@Injectable({
  providedIn: 'root'
})
export class RegisterService 
{
  private baseUrl = 'http://localhost:5555/emp';
  private adminUrl='http://localhost:5555/admin';
  public emp:CertificatePojo;
  public coreCertificate:CoreCertificatePojo;
  public training:Trainings;
  private planned:PlannedCertification;
  public voucherPC:PlannedCertification;
  cerid=localStorage.getItem('cerid');
  // trainingid=localStorage.getItem('trainingid');

  public plannedEmpCer:PlannedCertification;

  constructor(private http:HttpClient) { }
  login(){
    console.log("entered service");
    return false;
  }
  selectedPc(p:PlannedCertification){
  this.voucherPC=p;
  }

  savePlannedCer(a:PlannedCertification){
    this.plannedEmpCer=a;

  }
  create(register: Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/register`,register);
  }
  addEmpCer(c: CertificatePojo): Observable<any>
  {
    c.empId=localStorage.getItem("empId");
    c.empName=localStorage.getItem("empName");
     return this.http.post(`${this.baseUrl}`+`/add`,c);
}


uploadpdf(id:string,file: File): Observable<any> {
  const formdata: FormData = new FormData();
  formdata.append('file', file);

  // const req = new HttpRequest('POST', 'http://localhost:5555/emp/savePdf', {id,formdata}, {
  //   reportProgress: true,
  //   responseType: 'text'
  // }
  // );
  // return this.http.request(req);
      return this.http.post(`${this.baseUrl}`+`/savePdf/`+`${id}`,formdata);

}


validateEmployee(employee: Object): Observable<EmployeePojo>
  {
    return this.http.post<EmployeePojo>(`${this.baseUrl}`+`/validate`,employee);
  }

  addNewAdmin(admregister:Object): Observable<Object>{
    return this.http.post(`${this.adminUrl}`+`/register`,admregister);
  }

  
  validateAdmin(admin:Object): Observable<Object>{
    return this.http.post(`${this.adminUrl}`+`/login`,admin);
  }

  store(element){
    this.emp=element;
  }
  storeCore(element)
  {
    this.coreCertificate=element;
  }
  getAllCoreCertify()
  {
    return this.coreCertificate;
  }
  storeTraining(element)
  {
    this.training=element;
  }
  getTraining()
  {
    return this.training;
  }
  
  // getTrainingById():Observable<Trainings[]>
  // {
  //   this.training= this.http.get<Trainings[]>(`${this.adminUrl}`+`/viewTrainingById/`+`${this.training.trainingId}`);
  //   return this.training;
  // }


  
  getCertificationCategory():Observable<string[]>{
    return this.http.get<string[]>(`${this.baseUrl}`+`/category`);
  }
  // getCertificateName(cerCategory:string):Observable<string[]>{
  //   console.log(cerCategory)
  //   return this.http.get<string[]>(`${this.baseUrl}`+`/certificates/`+`?category=`+`${cerCategory}`);
  // }
  getCertificateName(cerCategory:string):Observable<string[]>{
    console.log(cerCategory)
    return this.http.get<string[]>(`${this.baseUrl}`+`/certificates/`+`${cerCategory}`);
  }
  getalrecerti(){
    
    return this.emp;

  }
  getemployees():Observable<CertificatePojo[]>{
    //console.log(this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`));
    return this.http.get<CertificatePojo[]>(`${this.baseUrl}`+`/all`);
  }
  id=localStorage.getItem('empId');
  eid=+this.id;
  getEmpCer():Observable<CertificatePojo[]>{
    
    return this.http.get<CertificatePojo[]>(`${this.baseUrl}`+`/view/`+`${this.eid}`);
  }
  getEmpNameCer():Observable<CertificatePojo>{
    return this.http.get<CertificatePojo>(`${this.baseUrl}`+`/view/`+`${this.eid}`);
  }
  updEmpCer(register: Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/update`,register);
  }
  updPlanCer(register: object):Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/addMarks`,register);
  }
  getCoreCer():Observable<CoreCertificatePojo[]>{
    return this.http.get<CoreCertificatePojo[]>(`${this.adminUrl}`+`/getCertificates`);
  }
  addAdmCer(register: Object): Observable<Object>
  {
    return this.http.post(`${this.adminUrl}`+`/addCertificate`,register);
  }
  getCertificateTotal():Observable<Tower[]>{
    //console.log(this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`));
    return this.http.get<Tower[]>(`${this.adminUrl}`+`/towers`);
  }

  getVoucherTotal():Observable<AdminVoucherPojo[]>{
    //console.log(this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`));
   
    return this.http.get<AdminVoucherPojo[]>(`${this.adminUrl}`+`/voucherinfo`);
  }

  registerCertificate(register:object):Observable<PlannedCertification>{
    console.log(register);
    return this.http.post<PlannedCertification>(`${this.baseUrl}`+`/savePlannedCertificates`,register);
  }

  getPlannedCertificate():Observable<PlannedCertification[]>{
    return this.http.get<PlannedCertification[]>(`${this.baseUrl}`+`/plannedCertificates/`+`${this.eid}`);
  }

  storeplanned(elements){
    this.planned=elements;
  }

  editplanned(){
    return this.planned;
  }
  assignVoucherList():Observable<AssignVoucher[]>{
    //console.log(this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`));
    return this.http.get<AssignVoucher[]>(`${this.adminUrl}`+`/getrequestlist`);
    }
    getAllVoucherDetails():Observable<voucher[]>{
      return this.http.get<voucher[]>(`${this.adminUrl}`+`/getallvouchers`+`?examName=${this.voucherPC.examName}`);
    }
    
    getProgressScores():Observable<number[]>
    {
    return this.http.get<number[]>(`${this.baseUrl}`+`/score`);
    
    }
    addExamScore(score: Object): Observable<PlannedCertification>
    {
    return this.http.post<PlannedCertification>(`${this.baseUrl}`+`/addMarks`,score);
    } 
     getAssignedVoucher(pc: Object): Observable<PlannedCertification>
     {
          return  this.http.post<PlannedCertification>(`${this.adminUrl}`+`/voucherassigned`,pc);
     }
     deleteCertification(id:any ): Observable<PlannedCertification> {  

        console.log(this.cerid);
      return this.http.delete<PlannedCertification>(`${this.baseUrl}/delete/${id}`);  
    }
    getTrainingDetails():Observable<Trainings[]>{
      return this.http.get<Trainings[]>(`${this.adminUrl}`+`/getTrainings`); 
    }
   
    addTraining(training: Object): Observable<Object>
  {
    return this.http.post(`${this.adminUrl}`+`/addTraining`,training);
  }
 

  deleteTraining(id:any ): Observable<Trainings> {  

   return this.http.delete<Trainings>(`${this.adminUrl}`+`/deleteTraining/`+`${id}`);  
 }


 requestingVoucher(a:PlannedCertification):Observable<any>{
   return this.http.post(`${this.baseUrl}`+`/requestVoucher`,a);

 }


 gettingAllVouchers():Observable<any>{
   return this.http.get(`${this.adminUrl}`+`/allvouchers`);

 }
 updateCoreCertification(c: Object): Observable<Object>
 {
   return this.http.post(`${this.adminUrl}`+`/editcertificationdetails`,c);
 }
 deleteCorecertification(id:any ): Observable<CoreCertificatePojo> {  

  return this.http.delete<CoreCertificatePojo>(`${this.adminUrl}`+`/deleteCertificationDetails/`+`${id}`);  
}

deleteyourCertification(c:CertificatePojo ): Observable<any> {  

  return this.http.post(`${this.baseUrl}`+`/deleteCertificate`,c);  
}

getAllCertificatesAdmin():Observable<any>{
  return this.http.get(`${this.adminUrl}`+`/getAllCertificatesAdmin`);

}
registerTraining(a:PlannedTrainings):Observable<any>{
  a.empId=localStorage.getItem("empId");
  a.empName=localStorage.getItem("empName");
  return this.http.post(`${this.baseUrl}`+`/registerTraining`,a);

}


updateTraining(c: Object): Observable<Object>
 {
   return this.http.post(`${this.adminUrl}`+`/updateTraining`,c);
 }

 getPlannedTrainings():Observable<PlannedTrainings[]>{
  return this.http.get<PlannedTrainings[]>(`${this.baseUrl}`+`/viewPlannedTrainings/`+`${this.eid}`);
}

showAdminPlannedTrainings():Observable<PlannedTrainings[]>{
  return this.http.get<PlannedTrainings[]>(`${this.adminUrl}`+`/viewRegisterTrainings`);
}

approveTraining(pc: Object): Observable<PlannedTrainings>
     {
       console.log('approve');
          return  this.http.post<PlannedTrainings>(`${this.adminUrl}`+`/approveTrainingRequest`,pc);
     }
    
     getTrainingsEmp():Observable<Trainings[]>{
      return this.http.get<Trainings[]>(`${this.baseUrl}`+`/getTrainings/`+`${this.eid}`);
    }
    
   uploadExcel(file: File): Observable<HttpEvent<{}>> {
      const formdata: FormData = new FormData();
      formdata.append('file', file);
      const req = new HttpRequest('POST', 'http://localhost:5555/admin/saveExcelFile', formdata, {
        reportProgress: true,
        responseType: 'text'
      }
      );
      return this.http.request(req);
    }


    
    // let headers = new Headers();
    // headers.append("content-Type",'multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW');
   
    getAllEmployee():Observable<any>{
      return this.http.get(`${this.adminUrl}`+`/getAllEmployee`);
    
    }

    downloadPdf(id:any):Observable<HttpResponse<any>>{
      console.log(id);
      // return this.http.get(`${this.baseUrl}`+`/Downloadpdf/`+`${id}`);
      let headers = new HttpHeaders();
        headers = headers.append('Accept', 'application/pdf');
   
      return this.http.get('http://localhost:5555/emp/Downloadpdf/' + id, {
          headers: headers,
        observe: 'response',
         responseType: 'blob'
      });
  
    
    }
   

    viewPdf(id:any): Observable<any> {


      return this.http.get('http://localhost:5555/emp/viewPdf/' + id, { responseType: 'blob' })
        .pipe(map(res => {
          return new Blob([res], { type: 'application/pdf', });
        }));


  }

      
  

}
