import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { RegisterService } from '../register.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { LoginComponent } from '../login/login.component';
import { AddEmpnewcertComponent } from '../add-empnewcert/add-empnewcert.component';
import { EditCertComponent } from '../edit-cert/edit-cert.component';
import { CertificatePojo } from '../certificatepojo';
import { UploadCertificateComponent } from '../upload-certificate/upload-certificate.component';

@Component({
  selector: 'app-already-certificate',
  templateUrl: './already-certificate.component.html',
  styleUrls: ['./already-certificate.component.css']
})
export class AlreadyCertificateComponent implements OnInit {

  displayedColumns: string[] = ['empId','empName','cerCategory','cerName', 'cerDate', 'expDate','cerMonth', 'examScore','voucherCode','certificate','upload','delete','edit'];
  dataSource = new MatTableDataSource();
  public popoverTitle: string = 'Certification Tracker';
  public popoverMessage: string = 'Are you sure you want to delete this certification ?';
  public cancelClicked;
  searchKey:string;
  emp:CertificatePojo;
  empName:string;
  cerName:string[];
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {
      
    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        iconRegistry.addSvgIcon(
          'delete',
          sanitizer.bypassSecurityTrustResourceUrl('assets/delete.svg'));
          iconRegistry.addSvgIcon(
            'edit',
            sanitizer.bypassSecurityTrustResourceUrl('assets/Edit.svg'));
            iconRegistry.addSvgIcon(
              'upload',
              sanitizer.bypassSecurityTrustResourceUrl('assets/upload.svg'));
  
      }
    
  ngOnInit(){
     

    this.res.getEmpCer().subscribe(res=>
      {
        this.dataSource.data=res;
      });
      
  }
  
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter(this.searchKey);

  }
  applyFilter(searchKey) {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
  oncreate()
  {
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.open(AddEmpnewcertComponent,dialogconfig); 
  }
  upload(element)
  {
    this.res.store(element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.open(UploadCertificateComponent,dialogconfig); 

  }
  onview(element)
  {
    this.res.store(element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.open(EditCertComponent,dialogconfig);
  }
  onCategory(cerCategory)
  {
    this.res.getCertificateName(cerCategory).subscribe(data=>{
      this.cerName = data as string[];
      console.log(this.cerName);
    });;

  }
  deleteCertification(emp)
  {

    this.res.deleteyourCertification(emp)  
      .subscribe(  
        data => {  
          console.log(data);    
        },  
        error => console.log(error));  
      // location.href= 'http://localhost:4200/alreadycert';
      window.location.reload();

  
}
}

