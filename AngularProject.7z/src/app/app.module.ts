import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { MatMenuModule } from '@angular/material/menu';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SideComponent } from './side/side.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatInputModule, MatNativeDateModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { AlreadyCertificateComponent } from './already-certificate/already-certificate.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { MatDialogModule } from '@angular/material/dialog';
import { AddEmpnewcertComponent } from './add-empnewcert/add-empnewcert.component';
import { EditCertComponent } from './edit-cert/edit-cert.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminConfigarationComponent } from './admin-configaration/admin-configaration.component';
import { AdminVocherComponent } from './admin-vocher/admin-vocher.component';
import { AdminAddCorecertComponent } from './admin-add-corecert/admin-add-corecert.component';
import { NewAdminRegisterComponent } from './new-admin-register/new-admin-register.component';
import { EmpRegCerComponent } from './emp-reg-cer/emp-reg-cer.component';
import { MatSelectModule } from '@angular/material/select';
import { CertificationProgressComponent } from './certification-progress/certification-progress.component';
import { EditPlannedCertificationComponent } from './edit-planned-certification/edit-planned-certification.component';
import { VoucherListComponent } from './voucher-list/voucher-list.component';
import { TableListComponent } from './table-list/table-list.component';
import { ViewProgressComponent } from './view-progress/view-progress.component';
import { AddExamScoresComponent } from './add-exam-scores/add-exam-scores.component';
import { AssignVoucherComponent } from './assign-voucher/assign-voucher.component';
import { MatSortModule } from '@angular/material/sort';
import { TrainingDetailsComponent } from './training-details/training-details.component';
import { AddTrainingComponent } from './add-training/add-training.component';
import { AdminViewTrainingsComponent } from './admin-view-trainings/admin-view-trainings.component';
import { VoucherManagementComponent } from './voucher-management/voucher-management.component';
import { MatTabsModule } from '@angular/material/tabs';
import { AllVouchersComponent } from './all-vouchers/all-vouchers.component';
import { MatDatepickerModule } from '@angular/material/datepicker';

import { ConfirmationPopoverModule } from 'angular-confirmation-popover';
import { EditCertificationListComponent } from './edit-certification-list/edit-certification-list.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { AdminAddTestComponent } from './admin-add-test/admin-add-test.component';
import { AdminAllCertificationsShowComponent } from './admin-all-certifications-show/admin-all-certifications-show.component';
import { EmployeeTrainingRequestsComponent } from './employee-training-requests/employee-training-requests.component';
import { ShowAdminTrainingRequestsComponent } from './show-admin-training-requests/show-admin-training-requests.component';
import { EditTrainingComponent } from './edit-training/edit-training.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { ExcelService } from './excel.service';
import { UploadCertificateComponent } from './upload-certificate/upload-certificate.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { map } from 'rxjs/operators';

@NgModule({
  declarations: [
    AppComponent,
    SideComponent,
    LoginComponent,
    RegisterComponent,
    AlreadyCertificateComponent,
    AdminLoginComponent,
    AddEmpnewcertComponent,
    EditCertComponent,
    AdminDashboardComponent,
    AdminConfigarationComponent,
    AdminVocherComponent,
    AdminAddCorecertComponent,
    NewAdminRegisterComponent,
    EmpRegCerComponent,
    CertificationProgressComponent,
    EditPlannedCertificationComponent,
    VoucherListComponent,
    TableListComponent,
    ViewProgressComponent,
    AddExamScoresComponent,
    AssignVoucherComponent,
    TrainingDetailsComponent,
    AddTrainingComponent,
    AdminViewTrainingsComponent,
    VoucherManagementComponent,
    AllVouchersComponent,
    EditCertificationListComponent,
    AdminAddTestComponent,
    AdminAllCertificationsShowComponent,
    EmployeeTrainingRequestsComponent,
    ShowAdminTrainingRequestsComponent,
    EditTrainingComponent,
    EmployeeDetailsComponent,
    UploadCertificateComponent

  ],
  imports: [
    BrowserModule,
    PdfViewerModule,
    MatDatepickerModule,
    MatNativeDateModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MatPaginatorModule,
    LayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatFormFieldModule,
    MatToolbarModule,
    MatDialogModule,
    MatButtonModule,
    MatSidenavModule,
    MatMenuModule,
    MatInputModule,
    MatTableModule,
    MatIconModule,
    MatListModule,
    HttpClientModule,
    MatSortModule,
    MatTabsModule,

    ConfirmationPopoverModule.forRoot({
      confirmButtonType: 'danger' // set defaults here
    }),

    RouterModule.forRoot([
      {
        path: 'login',
        component: LoginComponent
      },
      {
        path: 'register',
        component: RegisterComponent
      },
      
      {
        path: 'cerprog',
        component: CertificationProgressComponent
      },
      {
        path: 'alreadycert',
        component: AlreadyCertificateComponent
      },
      {
        path: 'trainings',
        component: TrainingDetailsComponent
      },
      {
        path: 'adminlogin',
        component: AdminLoginComponent
      },
      {
        path: 'admindash',
        component: AdminDashboardComponent
      },
      {
        path: 'emp-reg-cer',
        component: EmpRegCerComponent
      },
      {
        path: 'newadminreg',
        component: NewAdminRegisterComponent
      },
      {
        path: 'adminconfig',
        component: AdminConfigarationComponent
      },
      {
        path: 'adminvocher',
        component: AdminVocherComponent
      },
      {
        path: 'assignVoucher',
        component: AssignVoucherComponent
      },
      {
        path: 'addExamScore',
        component: AddExamScoresComponent
      },
      {
        path: 'viewProgress',
        component: ViewProgressComponent
      },
      {
        path: 'voucherTable',
        component: TableListComponent
      },
      {
        path: 'voucherList',
        component: VoucherListComponent
      },
      {
        path: 'viewTrainings',
        component: AdminViewTrainingsComponent
      },
      {
        path: 'voucher-manage',
        component: VoucherManagementComponent
      },
      {
        path: 'allEmployeeCertifications',
        component:AdminAllCertificationsShowComponent

      },
      {
        path: 'plannedTrainings',
        component:EmployeeTrainingRequestsComponent

      },
      {
        path: 'trainingRequests',
        component:ShowAdminTrainingRequestsComponent

      },

      {
        path:'employee',
        component:EmployeeDetailsComponent
      },
     

    ])
  ],
  providers: [ExcelService],
  bootstrap: [AppComponent],
  entryComponents: [
    LoginComponent,
    AddEmpnewcertComponent,
    EditCertComponent,
    AdminAddCorecertComponent,
    EditPlannedCertificationComponent,
    AddExamScoresComponent,
    AddTrainingComponent,
    EditCertificationListComponent,
    EditTrainingComponent,
    UploadCertificateComponent
  ]
})
export class AppModule {
}
