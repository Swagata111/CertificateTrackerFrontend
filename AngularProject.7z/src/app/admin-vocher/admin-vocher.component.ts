import { Component, OnInit,ViewChild } from '@angular/core';
import { AdminVoucherPojo } from '../adminvoucherpojo';
import { MatTableDataSource, MatIconRegistry, MatSort } from '@angular/material';
import { RegisterService } from '../register.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-vocher',
  templateUrl: './admin-vocher.component.html',
  styleUrls: ['./admin-vocher.component.css']
})
export class AdminVocherComponent implements OnInit {

  displayedColumns: string[] = ['stream', 'certificationName', 'totalVouchers','utilizedCount', 'blockedCount','expiredCount','availableCount'];
  
  @ViewChild(MatSort, {static: false}) sort: MatSort;

  dataSource = new MatTableDataSource();
  
  searchKey:string;
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        
      }
    
  ngOnInit(){

    this.res.getVoucherTotal().subscribe(res=>
      {
        this.dataSource.sort = this.sort;

        this.dataSource.data=res;
        this.dataSource.sort = this.sort;


      });
      
  }

  

  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }

  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
}
