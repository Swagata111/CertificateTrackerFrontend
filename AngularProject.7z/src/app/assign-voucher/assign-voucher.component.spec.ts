import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignVoucherComponent } from './assign-voucher.component';

describe('AssignVoucherComponent', () => {
  let component: AssignVoucherComponent;
  let fixture: ComponentFixture<AssignVoucherComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignVoucherComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignVoucherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
