import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatIconRegistry, MatDialog, MatSort, MatDialogConfig } from '@angular/material';
import { AssignVoucher } from '../AssignVoucher';
import { BreakpointObserver } from '@angular/cdk/layout';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { ViewProgressComponent } from '../view-progress/view-progress.component';

@Component({
  selector: 'app-assign-voucher',
  templateUrl: './assign-voucher.component.html',
  styleUrls: ['./assign-voucher.component.css']
})
export class AssignVoucherComponent implements OnInit {

  displayedColumns: string[] = ['empId','empName','stream', 'examName', 'voucherReqDate','viewProgress'];
  dataSource = new MatTableDataSource();
  searchKey:string;
  voucher:AssignVoucher;
  @ViewChild(MatSort, {static: true}) sort: MatSort;



  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {
      
    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }
    
  ngOnInit(){
    
    this.res.assignVoucherList().subscribe(res=>
      {
        this.dataSource.data=res;
        this.dataSource.sort = this.sort;
         console.log(res);
      });     
  }
  
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter(this.searchKey);

  }
  applyFilter(searchKey) {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
  viewProgress(element)
  {
    this.res.store(element);
    this.res.selectedPc(element);
    console.log(element);
    this.route.navigateByUrl('viewProgress');

    // const dialogconfig =  new MatDialogConfig();
    // dialogconfig.disableClose = true;
    // dialogconfig.autoFocus= true;
    // this.dialog.open(ViewProgressComponent,dialogconfig);
  }

 

}
