import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-voucher-list',
  templateUrl: './voucher-list.component.html',
  styleUrls: ['./voucher-list.component.css']
})
export class VoucherListComponent implements OnInit {
//voucherList:any;
  //constructor(private res: RegisterService, private route:Router) { }
constructor()
{

}
  ngOnInit() {
  //   this.res.getAllVoucherDetails().subscribe(res=>this.voucherList=res)
  //   console.log(this.voucherList);
  // }

}
}
