import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort, MatIconRegistry, MatDialog, MatTableDataSource } from '@angular/material';
import { RegisterService } from '../register.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-training-requests',
  templateUrl: './employee-training-requests.component.html',
  styleUrls: ['./employee-training-requests.component.css']
})
export class EmployeeTrainingRequestsComponent implements OnInit {

  displayedColumns: string[] = ['trainingId','trainingName', 'trainingStatus','location','startDate', 'endDate','nominationStatus','requestDate'];
  dataSource = new MatTableDataSource();
  public popoverTitle: string = 'Certification Tracker';
  public popoverMessage: string = 'Are you sure you want to de-register for this training ?';

  public confirmClicked: boolean = false;
  public cancelClicked: boolean = false;

  @ViewChild(MatSort, {static: true}) sort: MatSort;

  searchKey:string;
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        iconRegistry.addSvgIcon(
          'delete',
          sanitizer.bypassSecurityTrustResourceUrl('assets/delete.svg'));
      
      }
    
  ngOnInit(){
    this.res.getPlannedTrainings().subscribe(res=>
      {
        console.log(res);
        this.dataSource.data=res;
        this.dataSource.sort = this.sort;

      });
  }
  
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }
  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
  deleteTraining(_id)
  {

    this.res.deleteTraining(_id)  
      .subscribe(  
        data => {  
          console.log(data);    
        },  
        error => console.log(error));
        window.location.reload();  
      // location.href= 'http://localhost:4200/plannedTrainings';

}
}
