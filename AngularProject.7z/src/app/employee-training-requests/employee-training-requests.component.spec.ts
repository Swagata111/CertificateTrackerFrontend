import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeTrainingRequestsComponent } from './employee-training-requests.component';

describe('EmployeeTrainingRequestsComponent', () => {
  let component: EmployeeTrainingRequestsComponent;
  let fixture: ComponentFixture<EmployeeTrainingRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeTrainingRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeTrainingRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
