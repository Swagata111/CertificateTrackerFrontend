import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { PlannedCertification } from '../plannedcertification';
import { MatDialogRef, MatIconRegistry } from '@angular/material';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import * as moment from 'moment';

@Component({
  selector: 'app-edit-planned-certification',
  templateUrl: './edit-planned-certification.component.html',
  styleUrls: ['./edit-planned-certification.component.css']
})
export class EditPlannedCertificationComponent implements OnInit {

  regForm: FormGroup;

  submitted= false;
  cerCat:string[];
  public todate = new Date();

  cerName:string[];

  model:PlannedCertification=new PlannedCertification();
  mode:PlannedCertification=new PlannedCertification();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<EditPlannedCertificationComponent>,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {

    this.model=this.log.editplanned();
    console.log("edit"+this.model.empId);

    this.log.getCertificationCategory().subscribe(data=>{
      this.cerCat = data as string[];
      console.log(this.cerCat);
    });

    this.regForm = this.fb.group({
      stream: [''],
  
      examName: [''],
      
      expectedDate: [''],

      voucherStatus:[''],
 
      regDate:[''],

      voucherCode: [''],
      
      voucherReqDate: [''],

      voucherAssignedDate:[''],
 
      // examDate:[''],

      result: [''],

      score:[''],
 
      comments:[''],
      
    });
  }
  reg(){
    this.submitted = true;
    this.model=new PlannedCertification();

  }
  check=false;
  onUpdate(){

    const momentDate = new Date(this.model.expectedDate); // Replace event.value with your date value
    const formattedDate = moment(momentDate).format("YYYY-MM-DD");

    const obj={
      empId:localStorage.getItem('empId'),
      empName:localStorage.getItem('empName'),
      stream:this.model.stream,
      examName:this.model.examName,
      expectedDate: formattedDate,
      voucherStatus:this.model.voucherStatus,
      regDate:this.model.regDate,
      voucherCode: this.model.voucherCode,
      voucherReqDate: this.model.voucherReqDate,
      voucherAssignedDate:this.model.voucherAssignedDate,
      // examDate:this.model.examDate,
      result: this.model.result,
      score:this.model.score,
      comments:this.model.comments,
        testMarks:this.model.testMarks
    }

    console.log(obj)

    this.log.updPlanCer(obj)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)   
            this.route.navigateByUrl('cerprog');    
     
            // location.href='http://localhost:4200/cerprog';
      });

  }
  onCategory(cerCategory)
  {
    console.log(cerCategory);
    this.log.getCertificateName(cerCategory).subscribe(data=>{
      this.cerName = data as string[];
      console.log(this.cerName);
    });;

  }
   
  onclose(){
    this.dialogref.close();
  }
}
