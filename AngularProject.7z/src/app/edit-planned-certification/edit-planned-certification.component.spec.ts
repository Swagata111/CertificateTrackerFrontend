import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPlannedCertificationComponent } from './edit-planned-certification.component';

describe('EditPlannedCertificationComponent', () => {
  let component: EditPlannedCertificationComponent;
  let fixture: ComponentFixture<EditPlannedCertificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditPlannedCertificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPlannedCertificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
