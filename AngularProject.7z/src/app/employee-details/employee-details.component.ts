import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort, MatTableDataSource, MatPaginator, MatIconRegistry } from '@angular/material';
import { RegisterService } from '../register.service';
import { DomSanitizer } from '@angular/platform-browser';
import { BreakpointObserver } from '@angular/cdk/layout';
import { FormBuilder, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ExcelService } from '../excel.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

  displayedColumns: string[] = ['empId','empName','localGrade','mode','fresherOrlateral','cloudDoj','joiningDate','location','email','benchStartDate','agingDays','agingStatus','statusSince','ageofStatus','globalPractice','resignedLwd','loanedOut','currentWeekStatus','staffingAvailable','finalStaffingAvailable','billability','comments','finalStatus','proposedOrPendedTo','primarySkill','skill1Dasboarding'];
  length = 1000;
  pageSize = 5;
  showMsg:Boolean=false;
  public userFile:any= File;
  empIdFilter = new FormControl('');
  empNameFilter = new FormControl('');
  localGradeFilter = new FormControl('');
  fresherOrlateralFilter = new FormControl('');
  locationFilter = new FormControl('');
  globalPracticeFilter = new FormControl('');
  resignedLwdFilter = new FormControl('');
  finalStatusFilter = new FormControl('');


  filterValues = {
    empId: '',
    empName: '',
    localGrade: '',
    fresherOrlateral: '',
    location:'',
    globalPractice:'',
    resignedLwd:'',
    finalStatus:''
  };

  
  pageSizeOptions: number[] = [5, 10, 25, 50,100,150,200,500,1000,2000,3000,5000,10000];

  dataSource = new MatTableDataSource();
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  searchKey:string;
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, private excelService:ExcelService,
    sanitizer: DomSanitizer,
    private fb:FormBuilder,
    private route:Router) {


    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        iconRegistry.addSvgIcon(
          'upload',
          sanitizer.bypassSecurityTrustResourceUrl('assets/upload.svg'));
      
        
      }
    
  ngOnInit(){

    this.res.getAllEmployee().subscribe(res=>
      {
        this.dataSource.data=res;
        this.dataSource.sort=this.sort;

      });
    this.dataSource.paginator = this.paginator;
    this.dataSource.filterPredicate = this.createFilter();
    
    this.empIdFilter.valueChanges
    .subscribe(
      empId => {
        this.filterValues.empId = empId;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    )
  this.empNameFilter.valueChanges
    .subscribe(
      empName => {
        this.filterValues.empName = empName;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    )
  this.localGradeFilter.valueChanges
    .subscribe(
      localGrade => {
        this.filterValues.localGrade = localGrade;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    )
  this.fresherOrlateralFilter.valueChanges
    .subscribe(
      fresherOrlateral => {
        this.filterValues.fresherOrlateral = fresherOrlateral;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    )

    this.locationFilter.valueChanges
    .subscribe(
      location => {
        this.filterValues.location = location;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    )

    this.globalPracticeFilter.valueChanges
    .subscribe(
      globalPractice => {
        this.filterValues.globalPractice = globalPractice;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    )

    this.resignedLwdFilter.valueChanges
    .subscribe(
      resignedLwd => {
        this.filterValues.resignedLwd = resignedLwd;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    )

    this.finalStatusFilter.valueChanges
    .subscribe(
      finalStatus => {
        this.filterValues.finalStatus = finalStatus;
        this.dataSource.filter = JSON.stringify(this.filterValues);
      }
    )

       
  }

  onSearchClear(){
  this.searchKey = "";
    this.applyFilter();

  }

  clearName()
  {
    this.empNameFilter.setValue('');

  }

  clearId()
  {
  this.empIdFilter.setValue('');
  }

  clearLocation()
  {
    this.locationFilter.setValue('');
  }

  clearResigned()
  {
    this.resignedLwdFilter.setValue('');
  }

  clearLocalGrade()
  {
    this.localGradeFilter.setValue('');
  }

  clearFresherLateral()
  {
    this.fresherOrlateralFilter.setValue('');
  }

  clearGP()
  {
    this.globalPracticeFilter.setValue('');
  }
  clearFinalStatus()
  {
    this.finalStatusFilter.setValue('');
  }
  

  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
  selectedFiles: FileList;
   currentFileUpload: File;
  onSelectFile(event)
  {
    this.selectedFiles = event.target.files;
  }

  onAdd()
  {
    console.log('add');
    this.currentFileUpload = this.selectedFiles.item(0);
    this.res.uploadExcel(this.currentFileUpload).subscribe((response)=>
    {
    console.log(response);
    // this.showMsg= true;
      // this.regForm.reset();


     });
    this.selectedFiles=null;
    window.location.reload();

    //  alert('File uploaded successfully');

  }


  createFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function(data, filter): boolean {
      let searchTerms = JSON.parse(filter);
      return data.empId.toLowerCase().indexOf(searchTerms.empId) !== -1
        && data.empName.toString().toLowerCase().indexOf(searchTerms.empName) !== -1
        && data.localGrade.toLowerCase().indexOf(searchTerms.localGrade) !== -1
        && data.fresherOrlateral.toLowerCase().indexOf(searchTerms.fresherOrlateral) !== -1
        && data.location.toLowerCase().indexOf(searchTerms.location) !== -1
        && data.resignedLwd.toLowerCase().indexOf(searchTerms.resignedLwd) !== -1
        && data.globalPractice.toLowerCase().indexOf(searchTerms.globalPractice) !== -1
        && data.finalStatus.toLowerCase().indexOf(searchTerms.finalStatus) !== -1;

    }
    return filterFunction;
  }
  exportAsXLSX():void {
    this.excelService.exportAsExcelFile(this.dataSource.filteredData, 'EmployeeDetailFiltered');
 }
 
}
