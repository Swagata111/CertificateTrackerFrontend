import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Trainings } from '../Trainings';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import { MatDialogRef, MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import * as moment from 'moment';

@Component({
  selector: 'app-edit-training',
  templateUrl: './edit-training.component.html',
  styleUrls: ['./edit-training.component.css']
})
export class EditTrainingComponent implements OnInit {

  regForm: FormGroup;

  submitted= false;
  public todate=new Date();

  model:Trainings=new Trainings();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<EditTrainingComponent>,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {

       this.model=this.log.getTraining();

       this.regForm = this.fb.group({
      trainingId: [''],

      trainingName: [''],
  
      stream: [''],
      
      startDate: [''],

      endDate:[''],

      startTime:[''],
      endTime: [''],

      trainerName:[''],

      city:[''],
      location:[''],
      status:[''],
      capacity: [''],
      interestsReceived: [''],
      confirmedOrApproved: [''],
      seatsRemaining: [''],

      
    });
  }
  reg(){
    this.submitted = true;
    this.model=new Trainings();

  }
  check=false;
  onUpdate(){
    const momentDate1 = new Date(this.model.endDate); // Replace event.value with your date value
    const formattedDate1 = moment(momentDate1).format("YYYY-MM-DD");

    const momentDate = new Date(this.model.startDate); // Replace event.value with your date value
    const formattedDate = moment(momentDate).format("YYYY-MM-DD");
    this.model.startDate=formattedDate;
    this.model.endDate=formattedDate1;
    
    this.log.updateTraining(this.model)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)   
            this.route.navigateByUrl('viewTrainings');    
     
            // location.href='http://localhost:4200/viewTrainings';
      });


  }
   
  onclose(){
    this.dialogref.close();
  }
}