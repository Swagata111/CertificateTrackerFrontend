import { Component, OnInit } from '@angular/core';
import { Scores } from '../scores';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import { MatIconRegistry } from '@angular/material';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import {MatDialogRef } from '@angular/material/dialog';
import { PlannedCertification } from '../plannedcertification';


@Component({
  selector: 'app-add-exam-scores',
  templateUrl: './add-exam-scores.component.html',
  styleUrls: ['./add-exam-scores.component.css']
})
export class AddExamScoresComponent implements OnInit {

  model:PlannedCertification=new PlannedCertification();
  regForm: FormGroup;
  scores:any;
  submitted= false;


  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<AddExamScoresComponent>,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }
      //itemList = this.log.plannedEmpCer.testMarks;
      i= [0,1,2,3,4,5,6,7];
      customTrackBy(index: number, obj: any): any {
        return index;
      }

  ngOnInit() {
    this.i= [0,1,2,3,4,5,6,7];
    console.log(this.i);

    this.scores=this.log.plannedEmpCer.testMarks;
    console.log(this.scores);
    this.regForm = this.fb.group({
      testMarks: ['', [Validators.required ]]
    })
  

  }

  onAdd()
    {

    
      this.submitted=true;
      console.log("hi");
      console.log(this.scores);

      this.model=this.log.plannedEmpCer
      this.model.testMarks=this.scores;
    
      console.log(this.model);
      this.log.addExamScore(this.model)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error) 
            this.route.navigateByUrl('cerprog');    
       
            // location.href='http://localhost:4200/cerprog';
      });

    }

  onclose(){
    this.dialogref.close();
  }
}
