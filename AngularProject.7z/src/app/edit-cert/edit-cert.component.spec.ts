import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCertComponent } from './edit-cert.component';

describe('EditCertComponent', () => {
  let component: EditCertComponent;
  let fixture: ComponentFixture<EditCertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditCertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
