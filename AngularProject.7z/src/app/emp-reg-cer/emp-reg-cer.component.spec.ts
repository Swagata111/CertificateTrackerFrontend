import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpRegCerComponent } from './emp-reg-cer.component';

describe('EmpRegCerComponent', () => {
  let component: EmpRegCerComponent;
  let fixture: ComponentFixture<EmpRegCerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpRegCerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpRegCerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
