import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RegisterService } from '../register.service';
import { MatIconRegistry, throwMatDuplicatedDrawerError } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { PlannedCertification } from '../plannedcertification';
import * as moment from 'moment';

@Component({
  selector: 'app-emp-reg-cer',
  templateUrl: './emp-reg-cer.component.html',
  styleUrls: ['./emp-reg-cer.component.css']
})
export class EmpRegCerComponent implements OnInit {

  regForm: FormGroup;
  public todate = new Date();

today:number;
  submitted= false;
  cerCat:string[];
  cerName:string[];
  model:PlannedCertification=new PlannedCertification();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {

    this.log.getCertificationCategory().subscribe(data=>{
      this.cerCat = data as string[];
      console.log(this.cerCat);
    });
    this.regForm = this.fb.group({

      stream: ['', [Validators.required ]],
  
      examName: ['',[ Validators.required] ],
      
      expectedDate: ['',[Validators.required]],

    });
  }
  reg(){
    this.submitted = true;
    this.model=new PlannedCertification();

  }
  check=false;
  onAdd(){
    this.submitted=true;
    this.check=true;

    const momentDate = new Date(this.model.expectedDate); // Replace event.value with your date value
    const formattedDate = moment(momentDate).format("YYYY-MM-DD");
    console.log(formattedDate);
   
    const obj={
      empId:localStorage.getItem('empId'),
      empName:localStorage.getItem('empName'),
      stream:this.model.stream,
      examName:this.model.examName,
      expectedDate:formattedDate,
      testMarks:[0]
    }
    console.log(this.model.examName);
    this.log.registerCertificate(obj)
      .subscribe((data) =>{
        if(data==null){
            alert('You have already registered for this certification');
        }
            console.log(data),error=>console.error(error)        
            this.route.navigateByUrl('cerprog');    
      });


  }
  onCategory(cerCategory)
  {
    console.log(cerCategory);
    this.log.getCertificateName(cerCategory).subscribe(data=>{
      this.cerName = data as string[];
      // console.log(this.cerName);
    });;

  }
  
}

