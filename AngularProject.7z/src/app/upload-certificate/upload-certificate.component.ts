import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry, MatDialogRef } from '@angular/material';
import { FormBuilder } from '@angular/forms';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import { CertificatePojo } from '../certificatepojo';

@Component({
  selector: 'app-upload-certificate',
  templateUrl: './upload-certificate.component.html',
  styleUrls: ['./upload-certificate.component.css']
})
export class UploadCertificateComponent implements OnInit {

  model:CertificatePojo=new CertificatePojo();

  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<UploadCertificateComponent>,
    iconRegistry: MatIconRegistry,
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        iconRegistry.addSvgIcon(
          'upload',
          sanitizer.bypassSecurityTrustResourceUrl('assets/upload.svg'));
  
      }

  ngOnInit() {
    this.model=this.log.getalrecerti();
    console.log(this.model._id);

  }

  selectedFiles: FileList;
  currentFileUpload: File;
 onSelectFile(event)
 {
   this.selectedFiles = event.target.files;
 }

 uploadpdf()
 {
   console.log('add');
   this.currentFileUpload = this.selectedFiles.item(0);
   this.log.uploadpdf(this.model._id,this.currentFileUpload).subscribe((response)=>
   {
   console.log(response);
    });
   this.selectedFiles=null;
   window.location.reload();
 }


   
  onclose(){
    this.dialogref.close();
  }
}