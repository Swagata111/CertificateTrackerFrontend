import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-add-test',
  templateUrl: './admin-add-test.component.html',
  styleUrls: ['./admin-add-test.component.css']
})
export class AdminAddTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
