import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEmpnewcertComponent } from './add-empnewcert.component';

describe('AddEmpnewcertComponent', () => {
  let component: AddEmpnewcertComponent;
  let fixture: ComponentFixture<AddEmpnewcertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEmpnewcertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEmpnewcertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
