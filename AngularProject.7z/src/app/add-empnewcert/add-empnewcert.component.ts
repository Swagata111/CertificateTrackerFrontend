import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder, NgModel } from '@angular/forms';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import {MatDialogRef } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material';
import { BreakpointObserver } from '@angular/cdk/layout';
import { CertificatePojo } from '../certificatepojo';

@Component({
  selector: 'app-add-empnewcert',
  templateUrl: './add-empnewcert.component.html',
  styleUrls: ['./add-empnewcert.component.css']
})
export class AddEmpnewcertComponent implements OnInit {
  regForm: FormGroup;

  submitted= false;

  cerCat:string[];
  cerName:string[];
  file:File;
  id:string;
  public userFile:any= File;

  model:CertificatePojo=new CertificatePojo();
  d:Date;
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<AddEmpnewcertComponent>,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {
      this.log.getCertificationCategory().subscribe(data=>{
        this.cerCat = data as string[];
      });
      this.regForm = this.fb.group({
        
        cerCategory: ['',[Validators.required]],

        cerName:['',[ Validators.required] ],
  
        cerDate:['',[ Validators.required]],   
        cerMonth: [''],
        voucherCode:[''],
        examScore:[''],
        // file:[''],
        expDate:[''],
  
        

      });
  }
  reg(){
    this.submitted = true;
    this.model=new CertificatePojo();

  }
  check=false;

  month()
  {
    var str = this.model.cerDate.substr(5,2); 
    var year = this.model.cerDate.substr(0,4); 
    var month;
    if(str=="01")
    month="Jan ".concat(year);
    if(str=="02")
    month="Feb ".concat(year);
    if(str=="03")
    month="Mar ".concat(year);
    if(str=="04")
    month="Apr ".concat(year);
    if(str=="05")
    month="May ".concat(year);
    if(str=="06")
    month="Jun ".concat(year);
    if(str=="07")
    month="Jul ".concat(year);
    if(str=="08")
    month="Aug ".concat(year);
    if(str=="09")
    month="Sep ".concat(year);
    if(str=="10")
    month="Oct ".concat(year);
    if(str=="11")
    month="Nov ".concat(year);
    if(str=="12")
    month="Dec ".concat(year);

    this.model.cerMonth=month;

  }

//  onSelectFile(event)
//  {
//   let reader = new FileReader();
//   console.log("ji"+this.selectedFiles);


//    this.selectedFiles = event.target.files[0];
//    console.log("ji"+this.selectedFiles);
  
//  }

  onAdd(){
    this.submitted=true;
    this.check=true;
// console.log("file"+this.model.file);
    // this.currentFileUpload = this.selectedFiles;
    // console.log(this.currentFileUpload.size);
    this.log.addEmpCer(this.model)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)
            // this.route.navigateByUrl('alreadycert'); 
            window.location.reload();
   
      });


  }

  selectedFiles: FileList;
   currentFileUpload: File;
  onSelectFile(event)
  {
    this.selectedFiles = event.target.files;
  }

  uploadpdf()
  {
    console.log('add');
    this.currentFileUpload = this.selectedFiles.item(0);
   this.id="35706";
    this.log.uploadpdf(this.id,this.currentFileUpload).subscribe((response)=>
    {
    console.log(response);

     });
    this.selectedFiles=null;
    window.location.reload();

    //  alert('File uploaded successfully');

  }


  onCategory(cerCategory)
  {
    console.log(cerCategory);
    this.log.getCertificateName(cerCategory).subscribe(data=>{
      this.cerName = data as string[];
    });;

  }
  onclose(){
    this.dialogref.close();
  }
}
