import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voucher-management',
  templateUrl: './voucher-management.component.html',
  styleUrls: ['./voucher-management.component.css']
})
export class VoucherManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
