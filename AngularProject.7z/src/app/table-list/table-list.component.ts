import { Component, OnInit,ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { BreakpointObserver } from '@angular/cdk/layout';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { CertificatePojo } from '../certificatepojo';
import { RegisterService } from '../register.service';
import { voucher } from '../voucher';
import { PlannedCertification } from '../plannedcertification';
import { MatSort } from '@angular/material';

@Component({
  selector: 'app-table-list',
  templateUrl: './table-list.component.html',
  styleUrls: ['./table-list.component.css']
})
export class TableListComponent implements OnInit {
  model: voucher[];
  displayedColumns: string[] = ['voucherCode','stream','examName', 'status', 'expiryDate','empId','empName','action'];

  dataSource = new MatTableDataSource();
  searchKey:string;
  emp:CertificatePojo;
  empName:string;
  cerName:string[];
  currentPc:PlannedCertification;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {
      
    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

     assign(element){
         console.log(element);
         this.currentPc=this.res.voucherPC;
         this.currentPc.voucherStatus="Assigned";
         this.currentPc.voucherCode=element.voucherCode;
         this.currentPc.voucherAssignedDate=String(Date.now());
         this.res.getAssignedVoucher(this.currentPc).subscribe();
         this.route.navigateByUrl('voucher-manage');

        // location.href="http://localhost:4200/voucher-manage";
     }
  ngOnInit() {
    this.res.getAllVoucherDetails().subscribe(res=>
    {
      this.dataSource.data=res;
      this.dataSource.sort = this.sort;

      console.log(res);

        });

  }
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }
  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }

}
