import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatIconRegistry, MatDialog } from '@angular/material';
import { RegisterService } from '../register.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-training-details',
  templateUrl: './training-details.component.html',
  styleUrls: ['./training-details.component.css']
})
export class TrainingDetailsComponent implements OnInit {

  
  displayedColumns: string[] = ['trainingName', 'stream','startDate', 'endDate','startTime','endTime','trainerName','city','location', 'capacity','seatsRemaining','register'];
  dataSource = new MatTableDataSource();
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  searchKey:string;
  public popoverTitle: string = 'Certification Tracker';
  public popoverMessage: string = 'Are you sure you want to register for this training?';

  public confirmClicked: boolean = false;
  public cancelClicked: boolean = false;

  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {
      
    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        iconRegistry.addSvgIcon(
          'register',
          sanitizer.bypassSecurityTrustResourceUrl('assets/register.svg'));
      
      }
    
  ngOnInit(){
    this.res.getTrainingsEmp().subscribe(res=>
      {
        console.log(res);
        this.dataSource.data=res;
        this.dataSource.sort = this.sort;

      });
  }
  
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }
  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
  register(element)
  {
    this.res.registerTraining(element)
    .subscribe((data) =>{
          console.log(data),error=>console.error(error) 
          this.route.navigateByUrl('plannedTrainings');
       
          // location.href='http://localhost:4200/plannedTrainings';
    });

  }
}

