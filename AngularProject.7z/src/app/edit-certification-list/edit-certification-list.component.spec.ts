import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCertificationListComponent } from './edit-certification-list.component';

describe('EditCertificationListComponent', () => {
  let component: EditCertificationListComponent;
  let fixture: ComponentFixture<EditCertificationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditCertificationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCertificationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
