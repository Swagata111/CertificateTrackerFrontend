import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CoreCertificatePojo } from '../corecertificatepojo';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import { MatDialogRef, MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-edit-certification-list',
  templateUrl: './edit-certification-list.component.html',
  styleUrls: ['./edit-certification-list.component.css']
})
export class EditCertificationListComponent implements OnInit {

  regForm: FormGroup;

  submitted= false;

  model:CoreCertificatePojo=new CoreCertificatePojo();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<EditCertificationListComponent>,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {

     this.model=this.log.getAllCoreCertify();
    // console.log("edit"+this.model.);

   
    this.regForm = this.fb.group({
      certificationCategory: [''],
  
      certificationName: [''],
      
      activeStatus: [''],

      coreCeritification:[''],
 
      level:[''],

      voucherAvailable: [''],
      
      
    });
  }
  reg(){
    this.submitted = true;
    this.model=new CoreCertificatePojo();

  }
  check=false;
  onUpdate(){
    this.log.updateCoreCertification(this.model)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)   
            this.route.navigateByUrl('adminconfig');    
     
            // location.href='http://localhost:4200/adminconfig';
      });


  }
   
  onclose(){
    this.dialogref.close();
  }
}