import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificationProgressComponent } from './certification-progress.component';

describe('CertificationProgressComponent', () => {
  let component: CertificationProgressComponent;
  let fixture: ComponentFixture<CertificationProgressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CertificationProgressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificationProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
