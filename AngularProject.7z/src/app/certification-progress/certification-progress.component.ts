import { Component, OnInit,ViewChild } from '@angular/core';
import { Tower } from '../tower';
import { MatTableDataSource, MatIconRegistry, MatDialog, MatDialogConfig, MatSort } from '@angular/material';
import { RegisterService } from '../register.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { PlannedCertification } from '../plannedcertification';
import { EditPlannedCertificationComponent } from '../edit-planned-certification/edit-planned-certification.component';
import { AddExamScoresComponent } from '../add-exam-scores/add-exam-scores.component';

@Component({
  selector: 'app-certification-progress',
  templateUrl: './certification-progress.component.html',
  styleUrls: ['./certification-progress.component.css']
})
export class CertificationProgressComponent implements OnInit {

  displayedColumns: string[] = ['stream', 'examName','regDate', 'expectedDate','voucherStatus','voucherReqDate','voucherAssignedDate','edit','delete','requestVoucher','viewprogress'];
  model: PlannedCertification[];
  public popoverTitle: string = 'Certification Tracker';
  public popoverMessage: string = 'Are you sure you want to de-register for this Certification ?';
  public confirmClicked: boolean = false;
  public cancelClicked: boolean = false;
  public popoverMessageRequest: string = 'Are you sure you want to request for this Voucher ?';
public Null:null;
  dataSource = new MatTableDataSource();
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  searchKey:string;
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        iconRegistry.addSvgIcon(
          'delete',
          sanitizer.bypassSecurityTrustResourceUrl('assets/delete.svg'));
          iconRegistry.addSvgIcon(
          'requestvoucher',
          sanitizer.bypassSecurityTrustResourceUrl('assets/request.svg'));
          iconRegistry.addSvgIcon(
          'viewprogress',
          sanitizer.bypassSecurityTrustResourceUrl('assets/eye.svg'));
          iconRegistry.addSvgIcon(
            'edit',
            sanitizer.bypassSecurityTrustResourceUrl('assets/view.svg'));
  
      
      }
    
  ngOnInit(){

    this.res.getPlannedCertificate().subscribe(res=>
      {
        console.log(res);
        this.dataSource.data=res;
        this.dataSource.sort = this.sort;


      });
  
  }

  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }

  applyFilter() 
  {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
  onEdit(element)
  {
    this.res.storeplanned(element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.open(EditPlannedCertificationComponent,dialogconfig); 
  }
  onViewProgress(element)
  {
    this.res.store(element);
    this.res.savePlannedCer(element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    this.dialog.open(AddExamScoresComponent,dialogconfig);

     }

     requestVoucher(element)
  {
    this.res.requestingVoucher(element).subscribe();
    // location.href="http://localhost:4200/cerprog"; 
    window.location.reload();
    

     }


     deleteCertification(_id)
  {
   // localStorage.setItem('cerid',_id);
     // console.log(_id);
      // if(confirm("Are you sure you want to de-register for this Certification ?")) {

    this.res.deleteCertification(_id)  
      .subscribe(  
        data => {  
          console.log(data);    
        },  
        error => console.log(error));  
        // alert('You have successfully de-registered the certification!');
        window.location.reload();

  //  }  
  }
  
}