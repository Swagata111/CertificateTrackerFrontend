import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Trainings } from '../Trainings';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import { MatDialogRef, MatIconRegistry } from '@angular/material';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import * as moment from 'moment';


@Component({
  selector: 'app-add-training',
  templateUrl: './add-training.component.html',
  styleUrls: ['./add-training.component.css']
})


export class AddTrainingComponent implements OnInit {

  regForm: FormGroup;
  public todate = new Date();
  submitted= false;

  model:Trainings=new Trainings();
  private stDate=this.model.startDate;

  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<AddTrainingComponent>,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {
      this.regForm = this.fb.group({
        trainingId: ['', [Validators.required ]],

        trainingName: ['', [Validators.required ]],
    
        stream: ['',[ Validators.required] ],
        
        startDate: ['',[Validators.required]],

        endDate:['',[ Validators.required] ],
  
        startTime:['',[ Validators.required]],
        endTime: ['',[Validators.required]],

        trainerName:['',[ Validators.required] ],
  
        city:['',[ Validators.required]],
        location:['',[ Validators.required]],
        status:['',[ Validators.required]],



        capacity: [''],

       

      });
  }
  check=false;
  onAdd(){
    this.submitted=true;
    this.check=true;
    const momentDate1 = new Date(this.model.endDate); // Replace event.value with your date value
    const formattedDate1 = moment(momentDate1).format("YYYY-MM-DD");

    const momentDate = new Date(this.model.startDate); // Replace event.value with your date value
    const formattedDate = moment(momentDate).format("YYYY-MM-DD");
    this.model.startDate=formattedDate;
    this.model.endDate=formattedDate1;
    this.log.addTraining(this.model)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)   
            this.route.navigateByUrl('viewTrainings');    
     
            // location.href='http://localhost:4200/viewTrainings';
      });


  }
 

  onclose(){
    this.dialogref.close();
  }
}
