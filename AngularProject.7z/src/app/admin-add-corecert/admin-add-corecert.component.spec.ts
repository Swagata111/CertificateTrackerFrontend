import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAddCorecertComponent } from './admin-add-corecert.component';

describe('AdminAddCorecertComponent', () => {
  let component: AdminAddCorecertComponent;
  let fixture: ComponentFixture<AdminAddCorecertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminAddCorecertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminAddCorecertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
