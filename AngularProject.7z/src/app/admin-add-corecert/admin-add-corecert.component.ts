import { Component, OnInit } from '@angular/core';
import { CoreCertificatePojo } from '../corecertificatepojo';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MatIconRegistry } from '@angular/material';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-admin-add-corecert',
  templateUrl: './admin-add-corecert.component.html',
  styleUrls: ['./admin-add-corecert.component.css']
})
export class AdminAddCorecertComponent implements OnInit {

  regForm: FormGroup;

  submitted= false;
  cerCat:string[];

  cerName:string[];
  
  model:CoreCertificatePojo=new CoreCertificatePojo();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<AdminAddCorecertComponent>,
    iconRegistry: MatIconRegistry, 
    private res: RegisterService,
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {

    this.log.getCertificationCategory().subscribe(data=>{
      this.cerCat = data as string[];
      console.log(this.cerCat);
    });

    this.regForm = this.fb.group({
      certificationCategory: ['', [Validators.required ]],
  
      certificationName: ['',[ Validators.required] ],
      
      activeStatus: ['',[Validators.required]],

      coreCeritification:['',[ Validators.required] ],
 
      // level:['',[ Validators.required]],

      voucherAvailable: ['',[ Validators.required] ],

    });
  }
  reg(){
    this.submitted = true;
    this.model=new CoreCertificatePojo();

  }
  check=false;
  onAdd(){
    this.submitted=true;
    this.check=true;
    this.log.addAdmCer(this.model)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)   
            this.route.navigateByUrl('adminconfig');         
            // location.href='http://localhost:4200/adminconfig';
      });


  }
  onCategory(cerCategory)
  {
    console.log(cerCategory);
    this.log.getCertificateName(cerCategory).subscribe(data=>{
      this.cerName = data as string[];
      console.log(this.cerName);
    });;

  }
  onclose(){
    this.dialogref.close();
  }
}
