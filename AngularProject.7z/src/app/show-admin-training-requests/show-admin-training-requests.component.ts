import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatIconRegistry, MatSort, MatTableDataSource } from '@angular/material';
import { BreakpointObserver } from '@angular/cdk/layout';
import { RegisterService } from '../register.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-show-admin-training-requests',
  templateUrl: './show-admin-training-requests.component.html',
  styleUrls: ['./show-admin-training-requests.component.css']
})
export class ShowAdminTrainingRequestsComponent implements OnInit {

  displayedColumns: string[] = ['empId','empName','trainingId','trainingName', 'trainingStatus','location','startDate', 'endDate','nominationStatus','requestDate','action'];
  dataSource = new MatTableDataSource();
  public popoverTitle: string = 'Certification Tracker';
  public popoverMessage: string = 'Are you sure you want to approve this training request?';

  public confirmClicked: boolean = false;
  public cancelClicked: boolean = false;

  @ViewChild(MatSort, {static: true}) sort: MatSort;

  searchKey:string;
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        iconRegistry.addSvgIcon(
          'approve',
          sanitizer.bypassSecurityTrustResourceUrl('assets/approve.svg'));
      
      }
    
  ngOnInit(){
    this.res.showAdminPlannedTrainings().subscribe(res=>
      {
        console.log(res);
        this.dataSource.data=res;
        this.dataSource.sort = this.sort;

      });
  }
  
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }
  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
  approve(training)
  {

    this.res.approveTraining(training)  
      .subscribe(  
        data => {  
          console.log(data);    
        },  
        error => console.log(error));
        window.location.reload();  
      // location.href= 'http://localhost:4200/trainingRequests';


}
}
