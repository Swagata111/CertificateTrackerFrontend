import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminViewTrainingsComponent } from './admin-view-trainings.component';

describe('AdminViewTrainingsComponent', () => {
  let component: AdminViewTrainingsComponent;
  let fixture: ComponentFixture<AdminViewTrainingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminViewTrainingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminViewTrainingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
