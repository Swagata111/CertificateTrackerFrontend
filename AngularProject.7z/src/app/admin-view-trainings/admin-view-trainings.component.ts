import { Component, OnInit,ViewChild} from '@angular/core';
import { MatTableDataSource, MatSort, MatIconRegistry, MatDialog, MatDialogConfig } from '@angular/material';
import { RegisterService } from '../register.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { AddTrainingComponent } from '../add-training/add-training.component';
import { EditTrainingComponent } from '../edit-training/edit-training.component';

@Component({
  selector: 'app-admin-view-trainings',
  templateUrl: './admin-view-trainings.component.html',
  styleUrls: ['./admin-view-trainings.component.css']
})
export class AdminViewTrainingsComponent implements OnInit {

  displayedColumns: string[] = ['trainingId','trainingName', 'stream','startDate', 'endDate','startTime','endTime','trainerName','city','location','status','capacity','interestsReceived','confirmedOrApproved','seatsRemaining', 'edit','delete'];
  dataSource = new MatTableDataSource();
  public popoverTitle: string = 'Certification Tracker';
  public popoverMessage: string = 'Are you sure you want to delete this training ?';

  public confirmClicked: boolean = false;
  public cancelClicked: boolean = false;

  @ViewChild(MatSort, {static: true}) sort: MatSort;

  searchKey:string;
  constructor(private res: RegisterService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router,private dialog:MatDialog) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
        iconRegistry.addSvgIcon(
          'delete',
          sanitizer.bypassSecurityTrustResourceUrl('assets/delete.svg'));
          iconRegistry.addSvgIcon(
            'edit',
            sanitizer.bypassSecurityTrustResourceUrl('assets/Edit.svg'));
        
      
      }
    
  ngOnInit(){
    this.res.getTrainingDetails().subscribe(res=>
      {
        this.dataSource.data=res;
        this.dataSource.sort = this.sort;

      });
  }
  
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }
  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
  oncreate()
  {
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    dialogconfig.width="75%";
    dialogconfig.height="550px";

    this.dialog.open(AddTrainingComponent,dialogconfig); 
  }

  onEdit(element)
  {
    this.res.storeTraining(element);
    const dialogconfig =  new MatDialogConfig();
    dialogconfig.disableClose = true;
    dialogconfig.autoFocus= true;
    dialogconfig.width="75%";
    dialogconfig.height="550px";

    this.dialog.open(EditTrainingComponent,dialogconfig); 
  }
  

  deleteTraining(_id)
  {

    // if(confirm("Are you sure you want to delete this Training ?")) {
    this.res.deleteTraining(_id)  
      .subscribe(  
        data => {  
          console.log(data);    
        },  
        error => console.log(error));  
        // alert('You have successfully deleted training!');
      // location.href= 'http://localhost:4200/viewTrainings';
       window.location.reload();
  // }
}
}
