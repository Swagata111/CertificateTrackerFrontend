export class voucher{
   voucherCode:string;
   examName:string;
   Stream:string;
   procurementDate:string;
   expiryDate:string;
   status:string;
   empId:string;
   empName:string
}